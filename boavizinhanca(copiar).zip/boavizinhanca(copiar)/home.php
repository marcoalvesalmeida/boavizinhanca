<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<meta name="description" content="Primeiro Site em Bootstrap"/>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/customize.css">
	<title>Boa Vizinhança</title>
</head>
<body>
	<div class="header-row header-banner" id="header-row">
	   <div class="container-fluid container-banner">
	      <div class="row"> 
	         <div class="col-xs-12"> 
	             <img src="bootstrap/img/header-bg.jpg" alt="Boa Vizinhança Banner" class="img-banner">

	         </div>     
	      </div>
	   </div>
	</div>
</body>
</html>